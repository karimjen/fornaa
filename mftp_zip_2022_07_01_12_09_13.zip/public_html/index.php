<?php
header("location:site/entree.php");
?>