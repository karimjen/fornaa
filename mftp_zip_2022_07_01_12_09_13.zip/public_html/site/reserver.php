<?php
	// Initialiser la session
	session_start();
	// Vérifiez si l'utilisateur est connecté, sinon redirigez-le vers la page de connexion
	if(!isset($_SESSION["email"])){
		header("Location: ../connexion/connexion.php");
		exit(); 
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Réserver</title>
	<link rel="stylesheet" type="text/css" href="site.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body class="reserver">
	<header>
		<nav>
		<input id="menu-toggle" type="checkbox" />
    	<label class='menu-button-container' for="menu-toggle">
    	<article class='menu-button'></article>
    	</label>
			<ul class="menu">
				<li class="onglet">
					<a href="entree.php">Accueil</a>
				</li>
				<li class="onglet">
					<a href="reserver.php">Réserver</a>
				</li>
				<li class="onglet">
					<a href="recrutement.php">Recrutement</a>
				</li>
			</ul>
		</nav>
		<h1 class="titre">
			AJ Transports
		</h1>
		<?php
		if(!isset($_SESSION["email"])){?>
		<button>
			<a href="../connexion/connexion.php">Connexion</a>
		</button><?php	 
		} else{?>
			<button>
			<a href="../connexion/deconnexion.php">déconnexion</a>
		</button><?php
		}
		?>
	</header>
	<section>
	<div id="tabBox">
		<div class="tabWrap">
			<form method="post">
			<input id="tab-01" name="tab" type="radio" checked />
			<label class="tab label-01" for="tab-01"><span>1</span></label>
			<article class="tabContent">
			<h1>Détail du trajet</h1><br><br>
			<table>
				<tr>
					<td>
						<label>Date</label><br>
						<input type="date" name="" required>
					</td>
					<td>
						<label>Heure</label><br>
						<input type="time" name="" required>
					</td>
				</tr>
				<tr>
					<td>
						<br><label>Lieu de départ</label><br>
						<input type="text" name="" placeholder="Lieu de départ" required>
					</td>
					<td>
						<br><label>Lieu d'arriver</label><br>
						<input type="text" name="" placeholder="Lieu d'arriver'" required>
					</td>
				</tr>
				<script type='text/javascript' src="map.js"></script>
			</table>
			<br><br>
			<button><label for="tab-02">Choix du véhicule</label></button>
			</article>
		</div>
		<div class="tabWrap">
			<input id="tab-02" name="tab" type="radio" />
			<label class="tab label-02" for="tab-02"><span>2</span></label>
			<article class="tabContent">
			<h1>Choix du véhicule</h1><br><br>
			<input type="button" name="" id="expert" value="expert">
			<label for="expert"> Peugeot expert<br>6 place   prix:</label><br><br>
			<input type="button" name="" id="auris" value="auris">
			<label for="auris"> Toyota auris<br>3 place   prix:</label><br><br>
			<button><label for="tab-02">Récapitulatif</label></button>
			</article>
		</div>
		<div class="tabWrap">
			<input id="tab-03" name="tab" type="radio" />
			<label class="tab label-03" for="tab-03"><span>3</span></label>
			<article class="tabContent">
			<h1>Récapitulatif</h1><br><br>

			<input type="submit" name="">
			</article>
			</form>
		</div>
		</div>
	
	</section>
	<footer>
		<h1>
			AJ Transports
		</h1>
		<div class="left box">
			<h2>Adresse</h2>
			<div class="content">
			  <div class="phone">
				<span class="fas fa-phone-alt"></span>
				<span class="text">06 41 58 94 40</span>
			  </div>
			  <div class="email">
				<span class="fas fa-envelope"></span>
				<span class="text">tunsijamil@hotmail.com</span>
			  </div>
			</div>
		  </div>
		  <br>
		  <div class="right box">
			<h2>Contactez-nous</h2> 	
			<div class="content">
			  <form method="post" action="traitement.php">
				<div class="email">
				  <div class="text">Email</div>
				  <input type="email" name="email" id="email" placeholder="Votre email" required>
				</div>
				<input type="hidden" name="objet" id="objet" value="contact">
				<div class="msg">
				  <div class="text">Message</div>
				  <input type="text" name="msg" id="msg" required>
				</div>
				<div class="btn">
				  <button type="submit" name="envoyer">Envoyer</button>
				</div>
			  </form>
			</div>
		  </div>				
	</footer>
</body>
</html>