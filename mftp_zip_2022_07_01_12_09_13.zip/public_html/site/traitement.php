<?php        
//si le bouton envoyer a été cliqué  
if (isset($_POST["envoyer"])){     
    //on recupère l'adresse email  
    $email = $_POST["email"];      
    //on recupère l'objet du message  
    $objet = $_POST["objet"];  
    //Verifie si le fournisseur prend en charge les r
    if(preg_match("#@(hotmail|live|msn).[a-z]{2,4}$#", $email_from)){
        $passage_ligne = "\n";
    }else{
        $passage_ligne = "\r\n";
    }

    $boundary = md5(rand()); // clé aléatoire de limite  

    function clean_string($string) {
        $bad = array("content-type","bcc:","to:","cc:","href");
        return str_replace($bad,"",$string);
    }
        
    $headers = "From: " . $passage_ligne; //Sender
    $headers.= "Reply-to: " . $passage_ligne;

    $headers.= "MIME-Version: 1.0" . $passage_ligne; //Version de MIME
    $headers.= 'Content-Type: multipart/mixed; boundary='.$boundary .' '. $passage_ligne;
    //on recupère le message  
    
    $msg = '--' . $boundary . $passage_ligne; //Séparateur d'ouverture
    $msg .= "Content-Type: text/plain; charset=utf-8" . $passage_ligne; //Type du contenu
    $msg .= "Content-Transfer-Encoding: 8bit" . $passage_ligne; //Encodage
    $msg .= $_POST["msg"];  
    $msg .= $passage_ligne;

    

//Pièce jointe
    if(isset($_FILES["fichier"]) &&  $_FILES['fichier']['name'] != ""){ //Vérifie sur formulaire envoyé et que le fichier existe
        $nom_fichier = $_FILES['fichier']['name'];
        $source = $_FILES['fichier']['tmp_name'];
        $type_fichier = $_FILES['fichier']['type'];
        $taille_fichier = $_FILES['fichier']['size'];


        if($nom_fichier != ".htaccess"){ //Vérifie que ce n'est pas un .htaccess
			 if($type_fichier == "application/pdf"){ //Soit un pdf
                 
                if ($taille_fichier <= 2097152) { //Taille supérieure à Mo (en octets)
                    $tabRemplacement = array("é"=>"e", "è"=>"e", "à"=>"a"); //Remplacement des caractères spéciaux
                    
                    $handle = fopen($source, 'r'); //Ouverture du fichier
                    $content = fread($handle, $taille_fichier); //Lecture du fichier
                    $encoded_content = chunk_split(base64_encode($content)); //Encodage
                    $f = fclose($handle); //Fermeture du fichier
                                
                    $msg .= $passage_ligne . "--" . $boundary . $passage_ligne; //Deuxième séparateur d'ouverture
                    $msg .= 'Content-type:'.$type_fichier.';name="'.$nom_fichier.'"'. $passage_ligne; //Type de contenu (application/pdf ou image/jpeg)
                    $msg .='Content-Disposition: attachment; filename="'.$nom_fichier.'"'. $passage_ligne; //Précision de pièce jointe
                    $msg .= 'Content-transfer-encoding:base64'. $passage_ligne; //Encodage
                    $msg .= $passage_ligne; //Ligne blanche. IMPORTANT !
                    $msg .= $encoded_content. $passage_ligne; //Pièce jointe

                }
            }
        }
    }
$msg .= $passage_ligne . "--" . $boundary . "--" . $passage_ligne; //Séparateur de fermeture
    $to = "ajtransports92400@gmail.com";          
    //on envoie le message avec la fonction mail  
    if (mail($to,$objet,$msg,'',$headers)){   
        //si le message a été envoyé, on le confirme  
        echo " ton message est bien envoyé.";    
        }   
        //sinon on n'affiche un message d'erreur  
        else{   
        echo "Une erreur s'est produite";   
    }   
}   






?>